package com.example.ecommerceapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class signup : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_signup)
    }
}